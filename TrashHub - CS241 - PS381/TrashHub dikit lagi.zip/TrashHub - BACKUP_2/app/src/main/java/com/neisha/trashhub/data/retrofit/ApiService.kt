package com.neisha.trashhub.data.retrofit

import com.neisha.trashhub.data.pref.response.*
import okhttp3.Interceptor
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*

interface ApiService {
    @FormUrlEncoded
    @POST("users/register")
    suspend fun register(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("confirmPassword") confirmPassword: String,
        @Field("phone") phone: String,
        @Field("mitra") mitra: String
    ): RegisterResponse


    @FormUrlEncoded
    @POST("users/login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): LoginResponse

    @GET("articles")
    suspend fun getArticles(
    ): ArticlesResponse

    @GET("articles/detail/{id}")
    suspend fun getArticleDetail(
        @Path("id") id: String
    ): DetailArticleResponse

    @GET("articles/search/{title}")
    suspend fun searchArticles(
        @Path("title") title: String
    ): SearchArticleResponse

    @GET("articles/news/{count}")
    suspend fun getNewestArticles(
        @Path("count") count: Int
    ): NewestArticleResponse

    @POST("/predict/create")
    suspend fun createPredictionNoImage(): ErrorUploadResponse

    @POST("/predict/create")
    suspend fun createPredictionMoreThan1MB(): ErrorUploadResponse

    @POST("/predict/create")
    suspend fun createPredictionBadRequest(): ErrorUploadResponse


    @Multipart
    @POST("predict/create")
    suspend fun createPrediction(
        @Part image: MultipartBody.Part
    ): PredictionResponse

}


