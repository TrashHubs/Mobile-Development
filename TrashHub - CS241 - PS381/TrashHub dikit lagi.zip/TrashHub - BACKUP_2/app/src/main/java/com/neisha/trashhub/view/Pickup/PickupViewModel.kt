package com.neisha.trashhub.view.Pickup

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class PickupViewModel : ViewModel() {
    private val _weight = MutableLiveData<String>()
    val weight: LiveData<String> get() = _weight

    private val _phoneNumber = MutableLiveData<String>()
    val phoneNumber: LiveData<String> get() = _phoneNumber

    private val _additionalInfo = MutableLiveData<String>()
    val additionalInfo: LiveData<String> get() = _additionalInfo

    fun setWeight(weight: String) {
        _weight.value = weight
    }

    fun setPhoneNumber(phoneNumber: String) {
        _phoneNumber.value = phoneNumber
    }

    fun setAdditionalInfo(additionalInfo: String) {
        _additionalInfo.value = additionalInfo
    }
}