package com.neisha.trashhub.view.login

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.Observer
import androidx.lifecycle.asLiveData
import com.neisha.trashhub.data.pref.UserModel
import com.neisha.trashhub.data.pref.UserPreference
import com.neisha.trashhub.data.pref.response.LoginResponse
import com.neisha.trashhub.databinding.ActivityLoginBinding
import com.neisha.trashhub.view.main.MainActivity
import com.neisha.trashhub.viewmodel.LoginViewModel
import com.neisha.trashhub.viewmodel.ViewModelFactory

class LoginActivity : AppCompatActivity() {
    private val viewModel: LoginViewModel by viewModels {
        ViewModelFactory.getInstance(this)
    }

    private lateinit var binding: ActivityLoginBinding
    private lateinit var loadingIndicator: ProgressBar
    private lateinit var userPreference: UserPreference

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userPreference = UserPreference.getInstance(dataStore)

        setupView()
        setupAction()
        populateEmailFromIntent()

        viewModel.loading.observe(this) { isLoading ->
            loadingIndicator.isVisible = isLoading
        }

        viewModel.loginResult.observe(this) { result ->
            result.onSuccess { response: LoginResponse ->
                if (!response.error) {
                    response.loginResult?.let { loginResult ->
                        val userModel = UserModel(
                            id = loginResult.id,
                            name = loginResult.name,
                            email = loginResult.email,
                            token = loginResult.token,
                            phone = "",
                            roles = "",
                            isLogin = true
                        )
                        viewModel.saveSession(userModel)
                        showSuccessDialog()
                    }
                } else {
                    Toast.makeText(this, response.message ?: "Login gagal", Toast.LENGTH_SHORT)
                        .show()
                }
            }
            result.onFailure { error ->
                Toast.makeText(this, error.message ?: "Unknown error", Toast.LENGTH_SHORT).show()
            }
        }

        userPreference.getSession().asLiveData().observe(this, Observer { user ->
            user?.let {
                if (it.isLogin) {
                    navigateToMainActivity()
                }
            }
        })
    }

    private fun setupView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            @Suppress("DEPRECATION")
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()

        loadingIndicator = binding.progressBar
    }

    private fun setupAction() {
        binding.loginButton.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                viewModel.login(email, password)
            } else {
                Toast.makeText(this, "Email dan password harus diisi", Toast.LENGTH_SHORT).show()
            }
        }

        binding.registerTextView.setOnClickListener {
        }
    }

    private fun populateEmailFromIntent() {
        val email = intent.getStringExtra("email")
        email?.let {
            binding.emailEditText.setText(it)
        }
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this@LoginActivity, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    private fun showSuccessDialog() {
        if (!isFinishing) {
            AlertDialog.Builder(this).apply {
                setTitle("Success!")
                setMessage("Login successful")
                setPositiveButton("Continue") { _, _ ->
                    navigateToMainActivity()
                }
                setOnCancelListener {
                }
                create().apply {
                    setCanceledOnTouchOutside(false)
                    setCancelable(false)
                    show()
                }
            }
        }
    }
}
