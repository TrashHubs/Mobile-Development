package com.neisha.trashhub.view.Pickup

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.neisha.trashhub.databinding.ActivityPickupBinding

class PickupActivity : AppCompatActivity()  {
    private lateinit var binding: ActivityPickupBinding
    private val pickupViewModel: PickupViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPickupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Observe ViewModel data
        pickupViewModel.weight.observe(this, Observer { weight ->
            binding.weightInput.setText(weight)
        })

        pickupViewModel.phoneNumber.observe(this, Observer { phoneNumber ->
            binding.phoneNumber.setText(phoneNumber)
        })

        pickupViewModel.additionalInfo.observe(this, Observer { additionalInfo ->
            binding.additionalInfo.setText(additionalInfo)
        })

        // Set onClickListeners
        binding.backButton.setOnClickListener {
            finish()
        }

        binding.editButton.setOnClickListener {
            val phone = binding.phoneNumber.text.toString()
            pickupViewModel.setPhoneNumber(phone)
            Toast.makeText(this, "Phone number updated: $phone", Toast.LENGTH_SHORT).show()
        }

        binding.saveButton.setOnClickListener {
            val weight = binding.weightInput.text.toString()
            val phone = binding.phoneNumber.text.toString()
            val additionalInfo = binding.additionalInfo.text.toString()

            pickupViewModel.setWeight(weight)
            pickupViewModel.setPhoneNumber(phone)
            pickupViewModel.setAdditionalInfo(additionalInfo)

            Toast.makeText(this, "Data saved", Toast.LENGTH_SHORT).show()
        }

        // Initialize UI elements
        binding.weightInput.setOnFocusChangeListener { _, _ ->
            pickupViewModel.setWeight(binding.weightInput.text.toString())
        }

        binding.phoneNumber.setOnFocusChangeListener { _, _ ->
            pickupViewModel.setPhoneNumber(binding.phoneNumber.text.toString())
        }

        binding.additionalInfo.setOnFocusChangeListener { _, _ ->
            pickupViewModel.setAdditionalInfo(binding.additionalInfo.text.toString())
        }
    }
}