package com.neisha.trashhub.view.TrashDetection

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import com.neisha.trashhub.R
import com.neisha.trashhub.data.pref.UserPreference
import com.neisha.trashhub.data.pref.response.ErrorUploadResponse
import com.neisha.trashhub.data.pref.response.PredictionResponse
import com.neisha.trashhub.data.retrofit.ApiConfig
import com.neisha.trashhub.data.retrofit.ApiService
import com.neisha.trashhub.databinding.ActivityPredictionBinding
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.firstOrNull
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import retrofit2.HttpException
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class PredictionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPredictionBinding
    private var currentImageUri: Uri? = null

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

    private val requestCameraPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                Toast.makeText(this, "Camera permission granted", Toast.LENGTH_LONG).show()
                startCamera()
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_LONG).show()
            }
        }

    private val requestStoragePermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                Toast.makeText(this, "Storage permission granted", Toast.LENGTH_LONG).show()
                startGallery()
            } else {
                Toast.makeText(this, "Storage permission denied", Toast.LENGTH_LONG).show()
            }
        }

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPredictionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.galleryButton.setOnClickListener { checkGalleryPermission() }
        binding.cameraButton.setOnClickListener { checkCameraPermission() }
        binding.uploadButton.setOnClickListener { uploadImage() }
    }

    private fun checkGalleryPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startGallery()
        } else {
            requestStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startGallery() {
        launcherGallery.launch("image/*")
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            currentImageUri = uri
            Log.d("Photo Picker", "Selected Uri: $uri")
            showImage()
        } else {
            Log.d("Photo Picker", "No media selected")
            showToast("No media selected")
        }
    }

    private fun startCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraIntent.resolveActivity(packageManager)?.also {
            startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap?
            imageBitmap?.let {
                binding.previewImageView.setImageBitmap(it)
                currentImageUri = getImageUriFromBitmap(it)
            }
        }
    }

    private fun getImageUriFromBitmap(bitmap: Bitmap): Uri {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val path = MediaStore.Images.Media.insertImage(
            contentResolver,
            bitmap,
            "JPEG_${timeStamp}",
            null
        )
        return Uri.parse(path)
    }

    private fun showImage() {
        currentImageUri?.let {
            binding.previewImageView.setImageURI(it)
        }
    }

    private fun uploadImage() {
        currentImageUri?.let { uri ->
            val imageFile = getFileFromUri(uri)
            imageFile?.let {
                val reducedFile = it.reduceFileImage() // Reduce image size if needed
                val photoPart = prepareImageFileForUpload(reducedFile)
                val userPreference = UserPreference.getInstance(this@PredictionActivity.dataStore)
                lifecycleScope.launch {
                    val token = userPreference.getSession().firstOrNull()?.token

                    if (token.isNullOrEmpty()) {
                        showToast("Token not found. Please login.")
                        return@launch
                    }

                    showLoading(true)
                    try {
                        val apiService = ApiConfig.getApiServiceWithToken(token)

                        // Perform validation before prediction
                        val validationResponse = validateImage(apiService)

                        if (validationResponse != null && validationResponse.error == true) {
                            handleErrorResponse(validationResponse)
                        } else {
                            // If validation succeeds, proceed with prediction
                            val predictionResponse = apiService.createPrediction(photoPart)
                            handlePredictionResponse(predictionResponse)
                        }
                    } catch (e: HttpException) {
                        if (e.code() == 401) {
                            showToast("Unauthorized. Please login again.")
                            showUnauthorizedDialog()
                        } else {
                            Log.e("PredictionActivity", "Error uploading image", e)
                            showToast("Error uploading image")
                        }
                    } catch (e: Exception) {
                        Log.e("PredictionActivity", "Error uploading image", e)
                        showToast("Error uploading image")
                    } finally {
                        showLoading(false)
                    }
                }
            }
        } ?: showToast(getString(R.string.empty_image_warning))
    }

    private fun showUnauthorizedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Unauthorized")
            .setMessage("Your session has expired. Please login again.")
            .setPositiveButton("OK") { _, _ ->
            }
            .setCancelable(false)
            .show()
    }

    private fun getFileFromUri(uri: Uri): File? {
        val contentResolver = contentResolver ?: return null

        val inputStream = contentResolver.openInputStream(uri) ?: return null

        val tempFile = File(cacheDir, "temp_image.jpg")
        tempFile.deleteOnExit()
        tempFile.outputStream().use { outputStream ->
            inputStream.copyTo(outputStream)
        }

        return tempFile
    }

    private fun prepareImageFileForUpload(file: File): MultipartBody.Part {
        val requestImageFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
        return MultipartBody.Part.createFormData(
            "image",
            file.name,
            requestImageFile
        )
    }

    private suspend fun validateImage(apiService: ApiService): ErrorUploadResponse? {
        return try {
            apiService.createPredictionNoImage()
        } catch (e: HttpException) {
            if (e.code() == 401) {
                Log.e("PredictionActivity", "Error validating image - Unauthorized", e)
                showToast("Unauthorized. Please login again.")
            } else {
                Log.e("PredictionActivity", "Error validating image", e)
                showToast("Error validating image")
            }
            null
        } catch (e: Exception) {
            Log.e("PredictionActivity", "Error validating image", e)
            null
        }
    }

    private fun handleErrorResponse(response: ErrorUploadResponse) {
        if (response.error == true) {
            when (response.message) {
                "Image file is required" -> showToast("Image file is required")
                "Image size must not exceed 1 MB!" -> showToast("Image size must not exceed 1 MB!")
                "The image format is not appropriate, please use an image with the correct formatting" -> showToast("The image format is not appropriate, please use an image with the correct formatting")
                else -> showToast("Unknown error occurred")
            }
        } else {
            showToast("Unknown error occurred")
        }
    }

    private fun handlePredictionResponse(response: PredictionResponse) {
        val predictionResult = response.predictionResult
        if (predictionResult != null) {
            val resultText = "result: ${predictionResult.result}\n" +
                    "suggestion: ${predictionResult.suggestion}\n" +
                    "explanation: ${predictionResult.explanation}\n" +
                    "recyclePercentage: ${predictionResult.recyclePercentage}"

            binding.resultTextView.text = resultText
        } else {
            showToast("Prediction result is null")
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressIndicator.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
