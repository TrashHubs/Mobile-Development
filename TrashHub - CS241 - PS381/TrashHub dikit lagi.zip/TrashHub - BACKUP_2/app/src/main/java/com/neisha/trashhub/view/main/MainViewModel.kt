package com.neisha.trashhub.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.neisha.trashhub.R
import com.neisha.trashhub.view.adapter.EducationAdapter

class MainViewModel : ViewModel() {

    private val _educationContent = MutableLiveData<List<EducationAdapter.EducationItem>>()
    val educationContent: LiveData<List<EducationAdapter.EducationItem>> get() = _educationContent

    init {
        loadEducationContent()
    }

    private fun loadEducationContent() {
        // Simulasi memuat data
        _educationContent.value = listOf(
            EducationAdapter.EducationItem(
                "Reduce, Reuse, Recycle",
                "01/01/2024",
                "Description for Reduce, Reuse, Recycle...",
                R.drawable.image1
            ),
            EducationAdapter.EducationItem(
                "The Importance of Sorting Waste",
                "02/01/2024",
                "Description for The Importance of Sorting Waste...",
                R.drawable.image2
            ),
            EducationAdapter.EducationItem(
                "Composting at Home",
                "03/01/2024",
                "Description for Composting at Home...",
                R.drawable.image3
            )
        )
    }
}
